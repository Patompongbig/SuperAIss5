
# Super AI 2025 - Contact Center Quality Assurance Toolkit

This repository contains a Python notebook designed for evaluating Thai language contact center conversations using Speech-to-Text (STT), preprocessing pipelines, and Large Language Models (LLMs) to automate quality assurance tasks.

## 🔧 Features

- 🎙️ Speech-to-Text transcription using Whisper
- 🔊 Audio preprocessing: mono conversion, normalization, noise reduction
- 🤖 Multiple AI agents evaluating:
  - Greeting quality
  - Script adherence
  - Politeness
  - Resolution effectiveness
- 🧠 LLM-powered prompt-based evaluation
- 🔍 Retrieval-Augmented Generation (RAG) for contextual accuracy
- 📁 Works with local models (e.g., LLaMA via Ollama)

## 🗂️ Structure

| Component        | Description                                      |
|------------------|--------------------------------------------------|
| `whisper`        | Transcribes Thai speech into text                |
| `librosa`, `pydub`, `noisereduce` | Audio preprocessing tools         |
| `Agent`, `Runner` from `crewai` or `openai-agents` | Modular evaluation agents |
| `FAISS` + `LangChain` | Build RAG QA pipeline for context-aware scoring |
| `Ollama`         | Use local LLMs like LLaMA for private inference  |

## ▶️ How to Run

1. Run the notebook:
```bash
jupyter notebook super_ai_2025.ipynb
```

3. (Optional) Add your `OPENAI_API_KEY` or configure `Ollama` locally.

## 📌 Notes

- All API keys have been removed for security. Replace `"YOUR_API_KEY"` where necessary.
- Thai transcription and evaluation models are supported.
- For LLM-based corrections or RAG, local or OpenAI APIs can be used interchangeably.

## 📄 License

MIT License
